#install.packages(c("timetk","lubridate"))
library(timetk)
library(lubridate)

getwd()#see the path of the working directory (WD). this is where files will be saved
setwd("enter path") #to set a different WD enter the path (optional)

ts<- read.csv("..../welcome_to_miami.csv") #load and save data into an object called ts

str(ts) #check the dataset sctructure
head(ts) #take a look at the first observations
summary(ts) #descriptive statistics of variables

ts$date <- ymd(ts$date)#format and overwrite date variable with lubridate

#produce graphs with timetk
#plot time series
plot_time_series(ts, date, miami, title="Temperature in Miami", .smooth=F, .interactive=F)
plot_time_series(ts, date, miami, title="Temperature in Miami", .smooth=T, .interactive=F) #with smooth curve
plot_time_series(ts, date, miami, title="Temperature in Miami", .smooth=T, .interactive=T) #interactive plot


#autocorrelation function and partial correlation
plot_acf_diagnostics(ts,date, miami, .interactive=F, .lags=1:12)

#decomposition
plot_stl_diagnostics(ts, date, miami,
						.feature_set=c("observed","season","trend", "remainder"),
						.trend="auto",
						.frequency="auto",
						.interactive=F
						)

#seasonality diagnostics
plot_seasonal_diagnostics(ts,date,miami)

#save graphs in pdf format
dev.print(pdf, "path name/filename.pdf")